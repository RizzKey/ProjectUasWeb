    <footer>
        <p>&copy; 2021 - Veno Setyoaji Wiratama - 311910363 - TI.19.A.2 - Universitas Pelita Bangsa</p>
    </footer>
    </div>
</body>
</html>
